public class Third{
public static void main (String []args){
System.out.println("====================================");
System.out.println("=\tStudent information\t\t=");
System.out.println("====================================");
System.out.println("=Name\t\t:ARDP Ranasignhe\t=");
System.out.println("=Reg No\t\t:DIS\\08\\M4\\1234\t=");
System.out.println("=Address\t:Malabe\t\t\t=");
System.out.println("====================================");
}
}