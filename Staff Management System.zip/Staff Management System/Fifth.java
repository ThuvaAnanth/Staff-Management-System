public class Fifth{
public static void main(String []args){
	int age = 23;
	if (age>18){
	  System.out.println("Adult");
	 }
	else
	  System.out.println("Child");
  }
}